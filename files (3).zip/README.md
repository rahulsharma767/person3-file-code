# Module C — Automatic DF Receiver Placement, Geometry, GDOP & Optimisation

**Person 3 work package. Completely standalone.**

No QGIS. No Person 1 GIS code. No Person 2 P.1812 / Longley-Rice / ray-tracing code.
No external APIs. No live geographic data. Runs end to end on synthetic inputs with
`numpy + pandas + scipy + matplotlib + pyyaml`.

```bash
pip install -r requirements.txt
python run_pipeline.py                 # full pipeline -> outputs/
python tests/run_all.py                # 68 tests, no pytest needed
pytest -q                              # if you have pytest
```

---

## 1. What this module does

```
config.yaml
   │
   ├─ Tx (lat, lon, alt) ──────────► local ENU frame (metres, Tx at origin)
   ├─ deployment polygon (lat/lon) ─► Polygon2D in metres
   └─ N receivers, constraints
              │
   [1] candidate generation      grid lattice | seeded random
   [2] constraint filtering      polygon, duplicates, Tx-Rx range window, mock LOS
   [6] synthetic propagation     clearly-labelled mock layer (weight 0.0 by default)
   [3] geometry                  ranges, bearings, baselines, angular separations
   [4] GDOP                      bearing-only CRLB, dimensioned + dimensionless
   [5] composite score           configurable weights, every term in [0,1]
   [7] greedy optimiser          best-pair seed + best marginal addition
   [8] global optimiser          simulated annealing (+ GA alternative) + swap polish
       exhaustive reference      brute force when C(K,N) is affordable
   [8] ablation                  random / max-distance / geometry-aware / optimised
   [9] visualisation             7 publication-quality figures
  [10] export                    CSV + GeoJSON + provenance JSON
```

### Repository layout

```
module_C_optimization/
├── README.md                    ← this file (architecture + mathematics)
├── requirements.txt
├── run_pipeline.py              ← CLI entry point
├── config/
│   ├── config.yaml              ← every tunable number lives here
│   └── integration_schemas.yaml ← the data contract with Person 1 / Person 2
├── notebooks/
│   └── optimization_demo.ipynb  ← calls src/, contains no algorithm logic
├── src/
│   ├── coordinates.py           ← WGS84 ↔ local ENU, Vincenty reference
│   ├── polygon_backend.py       ← Shapely-optional polygon engine
│   ├── candidate_generation.py  ← STEP 1
│   ├── constraints.py           ← STEP 2
│   ├── geometry.py              ← STEP 3
│   ├── gdop.py                  ← STEP 4  (the core mathematics)
│   ├── scoring.py               ← STEP 5
│   ├── mock_propagation.py      ← STEP 6  (SYNTHETIC — clearly fenced off)
│   ├── optimization.py          ← STEPS 7-8
│   ├── visualization.py         ← STEP 9
│   ├── export.py                ← STEP 10
│   └── pipeline.py              ← orchestration only
├── tests/                       ← 68 tests incl. closed-form GDOP checks
├── data/synthetic/
└── outputs/{plots,csv,geojson}/
```

---

## 2. Coordinate handling — and why degrees are never used for distance

Latitude and longitude are **angles**. At 19° N one degree of latitude is ≈111.3 km but
one degree of longitude is only ≈105.2 km. Computing a Euclidean distance directly on
(lat, lon) stretches one axis by ~5.8%, which silently corrupts baselines, bearings,
angular separations and therefore GDOP.

All geometry is done in a **local East-North-Up tangent plane with the transmitter at the
origin**. With origin (φ₀, λ₀) and WGS84 radii of curvature evaluated at the origin,

```
meridian radius        M = a(1-e²) / (1 - e² sin²φ₀)^{3/2}
prime-vertical radius  N = a / (1 - e² sin²φ₀)^{1/2}

x_east  = (λ - λ₀) · N cos φ₀      [m]
y_north = (φ - φ₀) · M             [m]
```

Latitude/longitude are preserved untouched and re-attached at export.

**Validated, not asserted.** `tests/test_coordinates.py` checks the ENU distances against
a **Vincenty inverse solution on the WGS84 ellipsoid** — an independent, iterative,
non-linearised formulation. Agreement is **better than 1 m over the whole 7 km polygon**
(worst observed: 0.48 m), and azimuths agree to better than 0.02°.

A spherical haversine is deliberately *not* used as the reference: the spherical mean
radius differs from the local meridian radius by ~0.4% at this latitude, which is metres
of error over kilometres and would swamp what we are trying to measure. There is a test
that documents exactly this.

**Limitation.** The dominant neglected effect is convergence of the meridians, bounded by
`r² tan φ₀ / 2R` ≈ 1.3 m at 7 km, 2.7 m at 10 km. Fine here (a 2° bearing error at 5 km
is already ~175 m of cross-range). Not fine for survey work beyond ~20 km — use UTM there.

---

## 3. Why receiver geometry matters for DF

A DF receiver does not measure position. It measures a **bearing** — a line of position
(LOP) from the receiver through the emitter. With angular uncertainty σ_θ, an LOP is not
a line but a wedge that widens with range:

```
cross-range uncertainty ≈ r · σ_θ
```

Two consequences, pulling in opposite directions:

1. **Cutting angle dominates.** Two LOPs crossing near 90° give a compact error ellipse.
   Crossing at a shallow angle gives a long thin slither — error area scales roughly as
   `1/|sin Δφ|`, where Δφ is the angular separation *as seen from the emitter*. Two
   receivers 10 km apart but on the same bearing from the Tx are, for triangulation,
   almost the same receiver.
2. **Range hurts.** Wedge width grows linearly with r, so pushing receivers to the far
   edge of the polygon degrades accuracy even while it may improve the cutting angle.

**This is why the objective is not "maximise distance".** Section 7 shows what that
strategy actually costs.

---

## 4. The GDOP model — stated, derived, and bounded

### 4.1 Which measurement model (and which one we refuse to fake)

Classical GPS GDOP is derived from **pseudorange** measurements with a 4×4 geometry
matrix including a clock-bias column. That model does not apply here: our receivers
measure no range, and there is no common clock bias to solve for. Copying the GPS formula
would be faking it, so we do not.

The model implemented is **2-D bearing-only (AOA) triangulation of a single stationary
emitter**:

- State: `p = [x, y]ᵀ`, the emitter position in the local plane. Two unknowns.
- Measurement from receiver *i* at `pᵢ`:
  `θᵢ = atan2(x − xᵢ, y − yᵢ) + nᵢ`  (azimuth clockwise from grid north; note
  `atan2(East, North)`)
- Noise: `nᵢ ~ N(0, σ_θ²)`, independent, identical variance by default.

Assumptions, all in one place:

| | |
|---|---|
| A1 | One stationary emitter |
| A2 | Bearing errors zero-mean, Gaussian, mutually independent |
| A3 | Planar problem; altitude ignored |
| A4 | Small-error linearisation about the true position |
| A5 | The assumed emitter position is known (we are *planning*, not estimating) |

### 4.2 The geometry matrix

Linearising about the assumed emitter position, with `Δx = x − xᵢ`, `Δy = y − yᵢ`,
`rᵢ = √(Δx² + Δy²)`, and `sin θᵢ = Δx/rᵢ`, `cos θᵢ = Δy/rᵢ`:

```
∂θᵢ/∂x =  Δy / rᵢ²  =  cos θᵢ / rᵢ
∂θᵢ/∂y = −Δx / rᵢ²  = −sin θᵢ / rᵢ
```

```
      ⎡ cos θ₁ / r₁   −sin θ₁ / r₁ ⎤
  H = ⎢      ⋮              ⋮       ⎥        (N × 2)
      ⎣ cos θ_N / r_N −sin θ_N / r_N⎦
```

Both physical facts are visible directly in **H**: the `1/rᵢ` factor weakens distant
receivers, and two receivers on the same bearing produce parallel rows, making **H**
rank-deficient.

`tests/test_gdop.py` verifies this Jacobian **against a central-difference numerical
derivative of the actual bearing function** — the check that catches a wrong sign or a
swapped `atan2` argument.

### 4.3 The metric, and its units

```
Fisher information   J = Hᵀ R⁻¹ H,    R = σ_θ² I
CRLB covariance      C = σ_θ² (Hᵀ H)⁻¹                 [m²]
GDOP                 = √( trace( (Hᵀ H)⁻¹ ) )
```

**Units matter and are usually glossed over.** Because the rows of **H** carry a 1/metre
factor, this GDOP has units of **metres per radian**. It is a transfer factor:

```
RMS position error [m] = σ_θ [rad] × GDOP [m/rad]
```

With σ_θ = 2° (0.0349 rad) and GDOP = 3,531 m/rad → **123 m** RMS. That is a usable
planning number.

We also report a **dimensionless range-free variant**, `gdop_unit`, obtained by setting
every `rᵢ = 1`. It isolates angular geometry from range and has a closed-form optimum:
the unit rows are unit vectors, `trace(Hᵀ H) = N`, and `1/λ₁ + 1/λ₂` subject to
`λ₁ + λ₂ = N` is minimised at `λ₁ = λ₂ = N/2`, giving

```
gdop_unit_min = 2 / √N        (1.414 for N=2, 1.155 for N=3)
```

achieved by uniform **axial** bearing spacing of 180/N degrees. The ratio
`gdop_unit_min / gdop_unit ∈ (0,1]` is the GDOP sub-score.

**These are verified as mathematics, not vibes.** The test suite checks:
the closed form `√2/|sin Δ|` for N=2 at five separations; that uniform axial spacing hits
`2/√N` exactly for N = 2,3,4,5; that **1,200 random configurations never beat the
theoretical optimum**; that GDOP scales linearly with range while unit-GDOP does not; and
that collinear and reciprocal-bearing geometries are flagged `singular` rather than
returning a quietly wrong number.

### 4.4 Limitations — read before quoting any number from this module

- The CRLB is a **lower bound** for an unbiased estimator. Real DF with multipath,
  calibration error, site error and antenna pattern effects does worse, often much worse.
- σ_θ is assumed equal at all sites. In reality it varies with SNR, frequency, aperture
  and clutter. `dop_metrics(weights=...)` already accepts per-site weights — feeding real
  per-site σ_θ from Person 2 is the single biggest accuracy improvement available.
- Systematic (correlated) bearing bias is not modelled at all. GDOP describes random
  error transfer only.
- 2-D only: no terrain height, elevation angle or ground-projection error.
- Excellent GDOP with no usable signal is worthless — hence the propagation hook, and
  hence keeping the two metric families strictly separate.
- **Nothing here has been validated against real DF measurements.**

---

## 5. Composite geometry score (Step 5)

GDOP is the principled quantity. Three practical reasons push to a weighted composite
anyway — and this is engineering judgement, not a derivation:

1. GDOP is evaluated at **one** assumed emitter position; angular diversity and spread
   proxy for robustness when that assumption is soft.
2. GDOP is blind to siting practicalities — two receivers 40 m apart can show acceptable
   GDOP yet share clutter, interference and a single point of failure.
3. The unit-GDOP surface is flat over large regions then spikes near degeneracy; softer
   terms give the search a usable gradient.

All sub-scores are normalised to [0, 1], 1 = good. Weights live in `config/config.yaml`:

| Term | Weight | What it is |
|---|---|---|
| `gdop` | 0.45 | `gdop_unit_min / gdop_unit` — the only term derived from a measurement model |
| `angular` | 0.25 | `1 − \|mean(e^{i2φ})\|`, axial circular diversity of the Tx→Rx bearings |
| `baseline` | 0.20 | `min` pairwise separation / target (the **weakest** pair, not the mean) |
| `range_balance` | 0.10 | half soft-window on Tx-Rx range, half `1 − std(r)/mean(r)` |
| `propagation` | **0.00** | SYNTHETIC — deliberately zero so no current result is driven by fabricated RF |

The doubled-angle transform in `angular` is the standard tool for axial circular data: a
bearing φ and φ+180° describe the same LOP direction, so the statistic must treat them as
identical. It does — there is a test for it.

**Stated caveat on redundancy:** `gdop` and `angular` are correlated; both punish shared
bearings. The composite is *not* an orthogonal decomposition, and weights should be read
as relative emphasis, not variance shares. Set `angular: 0.0, gdop: 0.70` for a near-pure
GDOP objective — on this test case the selection barely moves, which is itself a useful
robustness result.

---

## 6. Synthetic propagation (Step 6) — fenced off on purpose

> **Everything `src/mock_propagation.py` produces is fabricated. It is not RF data and not
> a propagation prediction.** Every field carries a `_mock` suffix, every row carries
> `is_synthetic = True`, the DataFrame carries `attrs["propagation_source"] =
> "SYNTHETIC_MOCK"`, the plot carries a red warning banner, and the default scoring weight
> is **0.00**.

The toy models, with transparent assumptions:

- **Path loss** — log-distance `PL(d) = PL(d₀) + 10n·log₁₀(d/d₀) + X_σ`, free-space
  reference `PL(d₀) = 20 log₁₀(4πd₀f/c)`, n = 3.2. `X_σ` is drawn from a **spatially
  correlated** random field (random-phase Fourier synthesis, ~1.5 km correlation length),
  not i.i.d. per site — i.i.d. noise would let the optimiser cherry-pick lucky pixels,
  an artefact that would not survive a real propagation model.
- **LOS** — `p_LOS(d) = clip(p₁ₖₘ · exp(−(d_km − 1)/L), 0.02, 0.99)`, thresholded from a
  second correlated field so LOS/NLOS forms contiguous patches, not salt-and-pepper.
- **Signal quality** — link margin mapped to [0,1] with an NLOS penalty.

No terrain, no diffraction, no clutter, no antenna patterns, no multipath physics.

**Swapping in the real thing is a one-function change.** `PropagationResult`
(`tx_id, rx_id, path_loss_db, signal_quality, los, multipath_metric`) is the contract;
`propagation_from_external(candidates, results)` ingests Person 2's CSV and returns the
identical table shape. The optimiser cannot tell the difference — which is the point.
`real_propagation()` exists as an explicit `NotImplementedError` stub so nothing can
silently pretend to be real. `config/integration_schemas.yaml` has the full contract.

---

## 7. Results — the ablation (Step 8)

Test case: Tx at 19.0760 N, 72.8777 E; 48.93 km² polygon; 900 m grid → 72 candidates,
71 after filtering; N = 3; min separation 1,200 m; σ_θ = 2°.

With C(71,3) = 57,155 the **global optimum is computable by brute force**, so these are
optimality *gaps*, not claims.

| Strategy | Score | unit-GDOP | RMS error @ 2° | min sep | min ang sep | ang diversity | evals | gap |
|---|---|---|---|---|---|---|---|---|
| Random (mean of 200) | 0.718 | 1.569 | 163 m | 2,461 m | 40.7° | 0.488 | 200 | 27.9% |
| **Max-distance** | 0.889 | 1.225 | **219 m** | **6,300 m** | 77.6° | 0.667 | 1 | 10.7% |
| Geometry-aware template | 0.995 | 1.155 | 128 m | 3,245 m | 60.6° | 0.986 | 36 | 0.07% |
| Greedy | 0.889 | 1.225 | 219 m | 6,300 m | 77.6° | 0.667 | 2,554 | 10.7% |
| **Simulated annealing** | **0.996** | **1.155** | **123 m** | 5,248 m | 119.1° | 0.986 | 8,213 | **0.00%** |
| Exhaustive (optimum) | 0.996 | 1.155 | 123 m | 5,248 m | 119.1° | 0.986 | 57,155 | — |

The numbers, not adjectives:

- **Max-distance placement wins the separation metric and loses the accuracy metric.**
  It achieves the largest minimum separation of any strategy (6,300 m) and the *worst*
  RMS position error of any non-random strategy (219 m vs 123 m — **78% worse**). Exactly
  the failure predicted in §3: the far corners of a compact polygon share similar bearings
  and sit at long range, so wedge width grows while cutting angle does not improve.
- **Greedy converged to the identical configuration as max-distance** here. This is the
  documented greedy failure mode, not a coincidence: the best *pair* is a far-corner pair
  (large baseline term, acceptable cutting angle), greedy commits to it, and no third site
  can repair the geometry. It burned 2,554 evaluations to reach a 10.7% gap.
- **Simulated annealing found the exact global optimum** using 8,213 evaluations — **7×
  cheaper than brute force**. Across 8 seeds it hits the optimum 6/8 times and averages a
  0.1% gap. The selected geometry is 3 receivers at ≈120° axial spacing with near-equal
  ranges, giving `unit_GDOP = 1.1547 = 2/√3` — **the theoretical optimum exactly**, and a
  circular error ellipse (condition number ≈ 1).
- **The cheap geometric template gets within 0.07%.** Honest finding: on a convex polygon
  with a dense grid, most of the achievable gain comes from *thinking about bearings at
  all*; the optimiser recovers the last fraction of a percent. If you need one takeaway
  for the integration meeting, it is that — not "use the fancy optimiser".
- Random placement is 27.9% off and only ~60% of trials even satisfy the separation
  constraint.

Selected receivers (`outputs/csv/selected_receivers.csv`):

| rx_id | candidate | latitude | longitude | range | bearing |
|---|---|---|---|---|---|
| RX01 | C0006 | 19.051543 | 72.892103 | 3,103 m | 150.8° |
| RX02 | C0028 | 19.075935 | 72.849345 | 2,984 m | 269.9° |
| RX03 | C0060 | 19.100326 | 72.892103 | 3,090 m | 29.4° |

### Why simulated annealing, and not Differential Evolution

This is a **subset-selection** problem: choose N of K discrete sites. DE is a *continuous*
optimiser — using it here means either abandoning the candidate set (and with it every
per-candidate constraint and propagation attribute) or round-and-repair hacks that destroy
DE's difference-vector geometry. SciPy makes it tempting; it is the wrong tool for a fixed
discrete candidate set. SA's natural neighbourhood — swap one selected site for one
unselected site — maps exactly onto "N of K" and keeps every iterate cardinality-feasible.
A GA is also implemented so the comparison is evidence rather than assertion; it lands
within ~0.7% here, consistently worse than SA on this landscape.

Both stochastic methods finish with a deterministic **best-improvement swap hill-climb**.
The composite objective is very flat near its maximum, so an annealing chain reliably lands
*near* the optimum but often not *on* it; the polish costs O(N·K) evaluations and closes
the gap. If DE ever becomes right — i.e. the requirement changes to "place receivers
anywhere in the polygon, continuously" — that is noted in `src/optimization.py`.

---

## 8. Outputs

```
outputs/
├── csv/
│   ├── selected_receivers.csv        ← the deliverable
│   ├── candidate_receivers.csv       ← full candidate table + mock propagation
│   ├── rejected_candidates.csv       ← with a reject_reason per row (auditable)
│   ├── optimization_results.csv      ← every method, score, evals, runtime
│   └── ablation_comparison.csv       ← the table in §7
├── geojson/
│   ├── selected_receivers.geojson    ← EPSG:4326, [lon, lat] per RFC 7946
│   ├── candidate_receivers.geojson
│   └── scenario.geojson              ← Tx + polygon, drops straight into QGIS
├── plots/
│   ├── 01_candidates.png             polygon + Tx + candidates + rejects
│   ├── 02_selected_receivers.png     selection, Tx-Rx lines, baselines, error ellipse
│   ├── 03_bearing_geometry.png       compass rose + angular separation matrix
│   ├── 04_gdop_field.png             CRLB error map over the whole area
│   ├── 05_method_comparison.png      the ablation, four metrics
│   ├── 06_convergence.png            best-so-far vs iteration, with the optimum line
│   └── 07_mock_propagation.png       SYNTHETIC layer, red warning banner
└── run_metadata.json                 ← config, seeds, versions, provenance warning
```

`04_gdop_field.png` answers the operationally interesting question the single-point GDOP
cannot: *given where I put my receivers, how well could I locate an emitter that turns up
somewhere else?* The bright ridges are the geometric degeneracies along the extended
baselines.

---

## 9. Reproducibility

Every random draw is seeded (`candidates.random_seed`, `mock_propagation.random_seed`,
`optimization.random_seed`, `ablation.random_seed`). `test_pipeline_is_deterministic`
runs the whole pipeline twice and asserts identical selections. `run_metadata.json`
records the config, seeds and library versions used for each run.

```bash
python run_pipeline.py --n-receivers 4 --spacing 600 --second-method genetic_algorithm
python run_pipeline.py --method random --no-plots
```

---

## 10. Honest status

| Claim | Status |
|---|---|
| Coordinate conversion | **Mathematically derived**, validated against Vincenty to <1 m |
| Bearing Jacobian, GDOP, CRLB | **Mathematically derived**, validated against closed forms and numerical differentiation |
| `2/√N` optimum, `√2/\|sin Δ\|` | **Proved and tested** |
| Composite score weights | **Engineering assumption** — documented, configurable, redundancy acknowledged |
| Minimum separation, range window | **Engineering assumption** — operational siting judgement |
| Path loss, LOS, signal quality, multipath | **SYNTHETIC / MOCK** — fabricated, weight 0.0, never to be reported as RF results |
| Terrain, diffraction, clutter, multipath physics | **Not implemented** — Person 2's module |
| Terrain LOS, DEM, GIS layers | **Not implemented** — Person 1's module |
| Operational accuracy | **NOT ESTABLISHED.** No real propagation model and no real DF measurements have been used. Predicted error figures are geometry-only lower bounds under the stated assumptions, and must not be presented as expected field performance until validated. |
