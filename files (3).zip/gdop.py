r"""
gdop.py
=======

STEP 4 - a mathematically defensible geometry-quality metric for DF.

-------------------------------------------------------------------------
1. WHICH MEASUREMENT MODEL WE ASSUME (stated explicitly, not assumed away)
-------------------------------------------------------------------------
Classical navigation GDOP (the GPS one) is derived from *pseudorange*
measurements and has a 4x4 geometry matrix with a clock column.  That model
does not apply here: our receivers do not measure range to the emitter, and
there is no common clock bias to solve for.  Copying the GPS formula would be
faking it, so we do not.

The model used in this module is **2-D bearing-only (AOA) triangulation of a
single stationary emitter**:

* State to be estimated:  p = [x, y]^T, the emitter position in the local ENU
  plane.  Two unknowns.
* Measurement from receiver i at p_i = [x_i, y_i]^T:

      theta_i = atan2(x - x_i,  y - y_i) + n_i

  i.e. the azimuth of the emitter as seen from receiver i, measured clockwise
  from local grid north.  (Note the argument order: atan2(East, North).)
* Noise:  n_i ~ N(0, sigma_theta^2), independent across receivers, identical
  variance by default.  ``weights`` lets you relax the "identical" part - that
  is the hook where Person 2's propagation/SNR output will eventually enter,
  because bearing variance scales roughly as 1/SNR.

Assumption set, in one place:
  A1  The emitter is stationary and there is exactly one of it.
  A2  Bearing errors are zero-mean, Gaussian, mutually independent.
  A3  The problem is planar; receiver and emitter altitude are ignored.
  A4  Errors are small enough that the linearisation about the true position
      is valid (the CRLB below is a local, small-error bound).
  A5  The emitter's true position is known when we evaluate the metric - which
      it is, because we are *planning* against an assumed emitter location,
      not estimating one.

-------------------------------------------------------------------------
2. THE GEOMETRY MATRIX
-------------------------------------------------------------------------
Linearise theta_i about the assumed emitter position.  With
Delta_x = x - x_i, Delta_y = y - y_i, r_i = sqrt(Delta_x^2 + Delta_y^2), and
using sin(theta_i) = Delta_x / r_i, cos(theta_i) = Delta_y / r_i:

    d theta_i / dx  =  Delta_y / r_i^2  =   cos(theta_i) / r_i
    d theta_i / dy  = -Delta_x / r_i^2  =  -sin(theta_i) / r_i

So the N x 2 Jacobian (the geometry matrix) is

            [  cos(theta_1)/r_1   -sin(theta_1)/r_1  ]
        H = [        ...                 ...         ]
            [  cos(theta_N)/r_N   -sin(theta_N)/r_N  ]

Two things are visible directly from H and both match physical intuition:
the 1/r_i factor means distant receivers contribute weaker rows (a fixed
angular error spans more metres at long range), and two receivers on the same
bearing from the emitter produce parallel rows, which makes H rank-deficient.

-------------------------------------------------------------------------
3. THE METRIC
-------------------------------------------------------------------------
Fisher information for the model above:      J = H^T R^-1 H,  R = sigma^2 I.
Cramer-Rao lower bound on the position covariance:

        C = (H^T R^-1 H)^-1 = sigma_theta^2 (H^T H)^-1      [m^2]

Define, exactly as in the navigation literature but for *this* model:

        GDOP = sqrt( trace( (H^T H)^-1 ) )

**Units matter and are usually glossed over.**  Because the rows of H carry a
1/metre factor, this GDOP has units of **metres per radian**.  It is a
transfer factor, not a dimensionless number:

        RMS position error [m]  =  sigma_theta [rad]  x  GDOP [m/rad]

That is a genuinely useful planning number: with sigma_theta = 2 deg
(= 0.0349 rad) and GDOP = 3000 m/rad, the expected position RMS error is
about 105 m.

We also report a **dimensionless, range-free variant**, ``gdop_unit``,
obtained by setting every r_i = 1.  This isolates the *angular* geometry from
the effect of range, which is what you want when comparing configurations that
sit at different distances, and it has a clean closed-form optimum:

    H_unit rows are unit vectors u_i = [cos theta_i, -sin theta_i].
    H_unit^T H_unit = sum_i u_i u_i^T  has trace N, so its eigenvalues sum to
    N.  trace of the inverse, 1/l_1 + 1/l_2 subject to l_1 + l_2 = N, is
    minimised when l_1 = l_2 = N/2, giving trace(inv) = 4/N and

        gdop_unit_min = 2 / sqrt(N)

For N = 2 that is 1.414 (achieved by two receivers 90 deg apart as seen from
the emitter); for N = 3, 1.155 (achieved by 120 deg spacing).  The ratio
``gdop_unit_min / gdop_unit`` therefore lands in (0, 1] and is used directly
as the GDOP sub-score in :mod:`src.scoring`.

-------------------------------------------------------------------------
4. LIMITATIONS - READ BEFORE QUOTING ANY NUMBER FROM THIS MODULE
-------------------------------------------------------------------------
* The CRLB is a *lower bound* on the covariance of an unbiased estimator.  A
  real DF system with multipath, calibration error, site error, antenna
  pattern effects or a non-Gaussian error distribution will do worse, often
  much worse.
* sigma_theta is assumed equal at all sites unless weights are given.  In
  reality it varies with SNR, frequency, array aperture and local clutter.
  Feeding real per-site sigma from Person 2's propagation output is the
  single biggest accuracy improvement available later.
* Systematic (correlated) bearing bias is not modelled at all.  GDOP only
  describes the *random* error transfer.
* The model is 2-D.  Terrain height, elevation angle and the resulting
  ground-projection error are ignored.
* GDOP is a geometry metric.  A configuration with excellent GDOP but no
  usable signal is worthless - which is precisely why the propagation hook
  exists and why these two families of metric are kept separate.
* **Nothing here has been validated against real DF measurements.**  Treat the
  output as a relative planning aid, not as a predicted accuracy.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Sequence

import numpy as np

__all__ = [
    "DOPResult",
    "bearing_jacobian",
    "dop_metrics",
    "optimal_unit_gdop",
    "gdop_field",
    "SINGULAR_GDOP",
]

#: Value reported when the geometry is degenerate (rank-deficient H).
SINGULAR_GDOP = float("inf")

#: Condition-number threshold beyond which we declare the geometry singular.
_COND_LIMIT = 1e10


@dataclass
class DOPResult:
    """Dilution-of-precision results for one receiver configuration."""

    gdop: float                 # sqrt(trace((H^T H)^-1)), metres per radian
    gdop_unit: float            # dimensionless, ranges normalised to 1
    gdop_unit_optimal: float    # 2 / sqrt(N), theoretical best for this N
    gdop_score: float           # gdop_unit_optimal / gdop_unit, in (0, 1]
    condition_number: float     # cond(H); 1 = perfectly balanced geometry
    east_dop: float             # sqrt(C_xx / sigma^2), metres per radian
    north_dop: float            # sqrt(C_yy / sigma^2), metres per radian
    singular: bool              # True if the geometry is (near) rank-deficient
    sigma_theta_deg: float      # assumed bearing sigma used for the ellipse
    rms_position_error_m: float # sigma_theta[rad] * gdop
    ellipse_semi_major_m: float # 1-sigma error ellipse, metres
    ellipse_semi_minor_m: float
    ellipse_orientation_deg: float  # azimuth of the major axis, deg from north
    cep50_m: float              # circular error probable, approximation

    def as_row(self) -> dict:
        """Flat dict for a results table."""
        return {k: v for k, v in self.__dict__.items()}


def bearing_jacobian(
    rx_xy: np.ndarray,
    tx_xy: Sequence[float] = (0.0, 0.0),
    unit_range: bool = False,
) -> np.ndarray:
    """
    Build the N x 2 bearing-only geometry matrix H (see module docstring, §2).

    Parameters
    ----------
    rx_xy : ndarray, shape (N, 2)
        Receiver positions, local ENU metres.
    tx_xy : sequence of 2 floats
        Assumed emitter position in the same frame.
    unit_range : bool
        If True, drop the 1/r_i factor (rows become unit vectors).  This gives
        the dimensionless, range-free angular geometry.

    Returns
    -------
    ndarray, shape (N, 2)
    """
    p = np.atleast_2d(np.asarray(rx_xy, dtype=float))
    t = np.asarray(tx_xy, dtype=float)
    dx = t[0] - p[:, 0]          # East offset, receiver -> emitter
    dy = t[1] - p[:, 1]          # North offset, receiver -> emitter
    r = np.hypot(dx, dy)
    if np.any(r < 1e-6):
        raise ValueError("receiver co-located with the emitter; Jacobian undefined")
    sin_t, cos_t = dx / r, dy / r          # sin/cos of the bearing theta_i
    scale = np.ones_like(r) if unit_range else 1.0 / r
    return np.column_stack([cos_t * scale, -sin_t * scale])


def optimal_unit_gdop(n_rx: int) -> float:
    """
    Theoretical minimum of the dimensionless unit-range GDOP for N receivers.

    ``2 / sqrt(N)`` - see module docstring §3 for the derivation.

    Examples
    --------
    >>> round(optimal_unit_gdop(2), 4)
    1.4142
    >>> round(optimal_unit_gdop(3), 4)
    1.1547
    """
    if n_rx < 2:
        raise ValueError("bearing-only 2-D positioning needs at least 2 receivers")
    return float(2.0 / np.sqrt(n_rx))


def _safe_inv_gram(h: np.ndarray) -> tuple[Optional[np.ndarray], float, bool]:
    """Return ((H^T H)^-1, cond(H), singular_flag), handling rank deficiency."""
    gram = h.T @ h
    try:
        cond_h = float(np.linalg.cond(h))
    except np.linalg.LinAlgError:  # pragma: no cover
        cond_h = np.inf
    if not np.isfinite(cond_h) or cond_h > _COND_LIMIT:
        return None, cond_h, True
    try:
        return np.linalg.inv(gram), cond_h, False
    except np.linalg.LinAlgError:  # pragma: no cover
        return None, cond_h, True


def dop_metrics(
    rx_xy: np.ndarray,
    tx_xy: Sequence[float] = (0.0, 0.0),
    sigma_theta_deg: float = 2.0,
    weights: Optional[np.ndarray] = None,
) -> DOPResult:
    """
    Full DOP / CRLB evaluation of one receiver configuration.

    Parameters
    ----------
    rx_xy : ndarray, shape (N, 2)
        Receiver positions, local ENU metres.  N >= 2.
    tx_xy : sequence of 2 floats
        Assumed emitter position (origin in the Tx-centred frame).
    sigma_theta_deg : float
        Assumed per-receiver 1-sigma bearing error, degrees.  Only scales the
        physical-error outputs; the pure geometry terms are independent of it.
    weights : ndarray, shape (N,), optional
        Relative measurement weights w_i (proportional to 1/sigma_i^2,
        normalised to mean 1).  This is the interface through which real
        per-site SNR from Person 2 will eventually modulate the geometry.

    Returns
    -------
    DOPResult

    Notes
    -----
    A degenerate configuration (all receivers on one bearing from the emitter,
    or fewer than 2 distinct bearings) yields ``singular=True`` and infinite
    DOP values rather than a silently wrong number.
    """
    p = np.atleast_2d(np.asarray(rx_xy, dtype=float))
    n = len(p)
    if n < 2:
        raise ValueError("at least 2 receivers are required")

    h = bearing_jacobian(p, tx_xy, unit_range=False)
    h_unit = bearing_jacobian(p, tx_xy, unit_range=True)

    if weights is not None:
        w = np.asarray(weights, dtype=float)
        if w.shape != (n,):
            raise ValueError(f"weights must have shape ({n},)")
        if np.any(w <= 0):
            raise ValueError("weights must be strictly positive")
        w = w / w.mean()
        sw = np.sqrt(w)[:, None]
        h, h_unit = h * sw, h_unit * sw

    inv_gram, cond_h, singular = _safe_inv_gram(h)
    inv_gram_u, _, singular_u = _safe_inv_gram(h_unit)

    sigma_rad = float(np.radians(sigma_theta_deg))
    gdop_unit_opt = optimal_unit_gdop(n)

    if singular or inv_gram is None or singular_u or inv_gram_u is None:
        return DOPResult(
            gdop=SINGULAR_GDOP,
            gdop_unit=SINGULAR_GDOP,
            gdop_unit_optimal=gdop_unit_opt,
            gdop_score=0.0,
            condition_number=cond_h,
            east_dop=SINGULAR_GDOP,
            north_dop=SINGULAR_GDOP,
            singular=True,
            sigma_theta_deg=float(sigma_theta_deg),
            rms_position_error_m=SINGULAR_GDOP,
            ellipse_semi_major_m=SINGULAR_GDOP,
            ellipse_semi_minor_m=SINGULAR_GDOP,
            ellipse_orientation_deg=float("nan"),
            cep50_m=SINGULAR_GDOP,
        )

    gdop = float(np.sqrt(np.trace(inv_gram)))
    gdop_unit = float(np.sqrt(np.trace(inv_gram_u)))

    # Position covariance at the assumed emitter location: C = sigma^2 (H^T H)^-1
    cov = (sigma_rad ** 2) * inv_gram
    evals, evecs = np.linalg.eigh(cov)
    order = np.argsort(evals)[::-1]
    evals, evecs = evals[order], evecs[:, order]
    semi_major = float(np.sqrt(max(evals[0], 0.0)))
    semi_minor = float(np.sqrt(max(evals[1], 0.0)))
    major_vec = evecs[:, 0]                       # (east, north) components
    orient = float(np.degrees(np.arctan2(major_vec[0], major_vec[1])) % 180.0)

    # CEP50 approximation, valid for axis ratios roughly in [0.25, 1].
    cep50 = 0.59 * (semi_major + semi_minor)

    return DOPResult(
        gdop=gdop,
        gdop_unit=gdop_unit,
        gdop_unit_optimal=gdop_unit_opt,
        gdop_score=float(np.clip(gdop_unit_opt / gdop_unit, 0.0, 1.0)),
        condition_number=cond_h,
        east_dop=float(np.sqrt(inv_gram[0, 0])),
        north_dop=float(np.sqrt(inv_gram[1, 1])),
        singular=False,
        sigma_theta_deg=float(sigma_theta_deg),
        rms_position_error_m=float(sigma_rad * gdop),
        ellipse_semi_major_m=semi_major,
        ellipse_semi_minor_m=semi_minor,
        ellipse_orientation_deg=orient,
        cep50_m=float(cep50),
    )


def gdop_field(
    rx_xy: np.ndarray,
    grid_x: np.ndarray,
    grid_y: np.ndarray,
    sigma_theta_deg: float = 2.0,
    clip_max: float = 1000.0,
) -> np.ndarray:
    """
    Evaluate the *position* RMS error over a grid of hypothetical emitter
    locations, for a fixed receiver configuration.

    This answers the operationally interesting question: "given where I put my
    receivers, how well could I locate an emitter that turns up *there*?"  The
    single-point GDOP only answers it for the one assumed emitter position.

    Parameters
    ----------
    rx_xy : ndarray, shape (N, 2)
    grid_x, grid_y : ndarray
        1-D coordinate vectors, metres (local ENU).
    sigma_theta_deg : float
        Assumed bearing sigma.
    clip_max : float
        Values above this (metres) are clipped, so the colour scale is not
        destroyed by the singularity along the receiver baselines.

    Returns
    -------
    ndarray, shape (len(grid_y), len(grid_x))
        RMS position error in metres, clipped.
    """
    p = np.atleast_2d(np.asarray(rx_xy, dtype=float))
    xx, yy = np.meshgrid(np.asarray(grid_x), np.asarray(grid_y), indexing="xy")
    sigma_rad = float(np.radians(sigma_theta_deg))

    # Vectorised over the grid: (G, N)
    dx = xx[..., None] - p[None, None, :, 0]
    dy = yy[..., None] - p[None, None, :, 1]
    r2 = dx * dx + dy * dy
    r2 = np.where(r2 < 1.0, 1.0, r2)        # guard at the receiver locations
    a = dy / r2                              #  d theta / dx
    b = -dx / r2                             #  d theta / dy

    # Gram matrix entries, summed over receivers
    g00 = np.sum(a * a, axis=-1)
    g01 = np.sum(a * b, axis=-1)
    g11 = np.sum(b * b, axis=-1)
    det = g00 * g11 - g01 * g01

    with np.errstate(divide="ignore", invalid="ignore"):
        trace_inv = np.where(np.abs(det) > 1e-30, (g00 + g11) / det, np.inf)
        rms = sigma_rad * np.sqrt(np.maximum(trace_inv, 0.0))
    return np.clip(np.nan_to_num(rms, nan=clip_max, posinf=clip_max), 0.0, clip_max)
