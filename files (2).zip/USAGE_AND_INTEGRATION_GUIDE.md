# Module C — Usage & Integration Guide

**Person 3 work package: Automatic DF Rx Placement, Geometry, GDOP, Optimization**

This document is the single reference for: what's finished, what's still missing,
how to run everything, and exactly what you and your teammates need to do at
integration time. It supplements `README.md` (which covers the mathematics and
the current results) rather than repeating it.

---

## PART 1 — WHAT'S STILL NOT DONE

Beyond the gaps already flagged (Plotly, a Person-1 LOS ingest function,
packaging, a synthetic-data generator, Shapely/GeoPandas paths being
code-complete but never executed since neither library is installed here),
here is everything else left, in three groups.

### 1.1 Missing tests

`visualization.py`, `export.py`, `scoring.py`, and `pipeline.py` have **no
dedicated test file**. They are only exercised indirectly, through the
end-to-end pipeline test in `tests/test_optimization.py`. That test proves the
pipeline runs and writes non-empty files — it does not check that a plot
axis is labelled correctly, that a GeoJSON coordinate is in the right order
for an edge case, or that `scoring.py`'s sub-score formulas hit specific
values the way `test_gdop.py` checks GDOP against closed forms. If a plotting
function silently drew the wrong thing, the current suite would not catch it
unless the file came out empty or the pipeline crashed.

### 1.2 Missing config keys

Two parameters are read by the code but have **no corresponding entry in
`config.yaml`**, so they silently fall back to hardcoded defaults with no
visibility to whoever edits the config:

- `scoring.sigma_theta_deg` — defaults to `2.0` inside `ScoringConfig`, but
  the config file's `scoring:` block never mentions it.
- `constraints.min_distance_to_boundary_m` — defaults to `0.0` (off) inside
  `ConstraintConfig`, same situation.

Anyone editing `config.yaml` to change these will find nothing to edit.

### 1.3 Modelling and scale gaps

- **Single stationary emitter only.** No multi-emitter case, no moving
  target, no receiver-failure robustness (what happens to the fix if one
  site goes offline after deployment).
- **AOA only.** No TDOA, no FDOA, no hybrid measurement model.
- **2-D only, end to end.** Altitude is parsed from config, carried through
  to output, and then ignored by every geometry and GDOP calculation.
- **Only ever tested on one polygon** — a convex rectangle. No concave
  polygon, no multi-lobe deployment area, no scenario with the Tx outside
  the polygon.
- **Only tested at one scale.** ~71 candidates, N = 2–4 receivers. The
  pairwise distance matrix is O(K²) in memory; nobody has checked behaviour
  at, say, 2,000 candidates.
- **`sigma_theta_deg` is a single fixed number per run.** No sensitivity
  sweep across a range of assumed bearing errors, and no per-site sigma
  even though `dop_metrics(weights=...)` already accepts it — there's just
  nothing in the pipeline that populates real per-site weights yet.
- **No packaging, no CI, no logging framework.** `print()` statements only;
  no `pyproject.toml`; nothing wired to GitHub Actions or similar.

None of this blocks a demo. All of it is legitimate follow-up work, and the
tests/config gaps in 1.1–1.2 are the two I'd close first since they're cheap
and they're the kind of thing that causes confusion months later.

---

## PART 2 — HOW TO RUN WHAT'S BUILT

### 2.1 One-time setup

```bash
cd module_C_optimization
python3 -m venv venv && source venv/bin/activate    # optional but recommended
pip install -r requirements.txt
```

Shapely and GeoPandas are in `requirements.txt` but are **optional** — the
code runs fully without them (see `src/polygon_backend.py`). Install them if
you want the Shapely-backed polygon validity check or the GeoPandas GeoJSON
writer; otherwise skip them and nothing breaks.

### 2.2 Run the whole pipeline

```bash
python run_pipeline.py
```

This reads `config/config.yaml`, runs all ten steps, and writes everything
under `outputs/`: five CSVs, three GeoJSONs, seven plots, and
`run_metadata.json`. It prints a summary table to the terminal as it goes.

Useful variations:

```bash
python run_pipeline.py --n-receivers 4                        # change N
python run_pipeline.py --method random --no-plots              # skip figures
python run_pipeline.py --spacing 600                            # finer grid
python run_pipeline.py --second-method genetic_algorithm        # swap optimiser
python run_pipeline.py --output /some/other/path                # custom output dir
python run_pipeline.py --quiet                                  # suppress logging
```

To change anything more deeply than the CLI flags allow — scoring weights,
constraint thresholds, the mock propagation model — edit `config/config.yaml`
directly and rerun. Every number the pipeline uses lives in that one file.

### 2.3 Run the tests

```bash
python tests/run_all.py            # bundled runner, no pytest required
# or, if you have pytest installed:
pytest -q
```

Expect 68 passing tests, ~100 seconds (the brute-force exhaustive checks
dominate the runtime). To run just one file's tests:

```bash
python tests/run_all.py gdop       # matches tests.test_gdop
```

### 2.4 Run the notebook

```bash
jupyter notebook notebooks/optimization_demo.ipynb
```

Every cell calls into `src/` — there's no logic duplicated in the notebook
itself, so it and the CLI will always agree. Run cells top to bottom; the
last section demonstrates the Person 2 integration hook (see Part 3).

### 2.5 Where to look at results

| What you want | Where |
|---|---|
| The final selected receivers | `outputs/csv/selected_receivers.csv` |
| Why a candidate was dropped | `outputs/csv/rejected_candidates.csv` (has a `reject_reason` column) |
| Which strategy won and by how much | `outputs/csv/ablation_comparison.csv` |
| A picture of the selection | `outputs/plots/02_selected_receivers.png` |
| The bearing geometry | `outputs/plots/03_bearing_geometry.png` |
| Predicted error over the whole area | `outputs/plots/04_gdop_field.png` |
| GeoJSON for QGIS / a map tool | `outputs/geojson/*.geojson` |
| What config/seeds produced a run | `outputs/run_metadata.json` |

---

## PART 3 — INTEGRATION: WHAT YOU NEED TO DO

Module C was built so that **nothing about it needs to be rewritten** when
Person 1 and Person 2 finish their modules. Only two small pieces of glue
code get added, and both are documented in `config/integration_schemas.yaml`.

### 3.1 Integrating Person 2 (RF propagation)

**What they need to hand you:** a CSV or DataFrame with these columns:

| Column | Type | Meaning |
|---|---|---|
| `rx_id` | string | Must match Module C's `candidate_id` |
| `path_loss_db` | float | Total path loss, dB |
| `signal_quality` | float in [0,1] | 1 = best |
| `los` | int | 1 = line of sight, 0 = obstructed |
| `multipath_metric` | float, optional | e.g. normalised RMS delay spread |
| `bearing_sigma_deg` | float, optional but valuable | per-site 1-sigma bearing error from SNR |

**What you do — one function call, already written:**

```python
from src.mock_propagation import propagation_from_external

# results = pd.read_csv("person2_output.csv")
real = propagation_from_external(candidates, results)
```

That's it. `real` has the exact same column names the mock propagation layer
produces (`path_loss_mock_db`, `signal_quality_mock`, etc. — yes, still
called `_mock` for schema consistency, but `is_synthetic` is now `False`),
so nothing downstream in `constraints.py`, `scoring.py`, or `optimization.py`
needs to change.

**To actually use the propagation quality in scoring**, edit
`config/config.yaml`:

```yaml
scoring:
  weights:
    propagation: 0.15   # currently 0.00 — raise this once real data is in
    gdop: 0.40           # and rebalance the others down accordingly
    angular: 0.20
    baseline: 0.15
    range_balance: 0.10
```

**For the higher-value integration** (per-site bearing sigma instead of a
single global value), you'll need to write a small amount of new code —
this part is *not* built yet:

```python
# does not exist yet — you'd add this to pipeline.py
weights = 1.0 / (per_site_sigma_deg ** 2)   # inverse-variance weighting
dop = dop_metrics(rx_xy, tx_xy, sigma_theta_deg=..., weights=weights)
```

`dop_metrics()` already accepts a `weights` argument and is tested with it
(`test_weights_change_the_result_and_are_validated`), but the pipeline
doesn't populate it from anywhere yet — that's on you to wire up once real
per-site sigma exists.

### 3.2 Integrating Person 1 (GIS / terrain / LOS)

**What they need to hand you:** a CSV with:

| Column | Type | Meaning |
|---|---|---|
| `rx_id` | string | Must match `candidate_id` |
| `latitude`, `longitude` | float | WGS84 |
| `los` | int | 1 = clear terrain LOS to Tx, 0 = obstructed |
| `terrain_obstruction`, `ground_elevation_m`, `clutter_class` | optional | |

**What you do — this function does NOT exist yet, you need to write it.**
Unlike the propagation side, I did not build a `los_from_external()`
equivalent. The pattern to follow (mirroring `propagation_from_external`
almost exactly):

```python
def los_from_external(candidates: pd.DataFrame, results: pd.DataFrame,
                       rx_id_column: str = "rx_id") -> pd.DataFrame:
    r = results.rename(columns={rx_id_column: "candidate_id"})
    merged = candidates.merge(
        r[["candidate_id", "los"]], on="candidate_id", how="left"
    )
    merged = merged.rename(columns={"los": "los_mock"})
    return merged
```

Put that in `src/mock_propagation.py` next to `propagation_from_external`,
then in `config/config.yaml` set:

```yaml
constraints:
  require_mock_los: true
```

Candidates without real terrain LOS will then be dropped before optimisation
rather than merely penalised afterwards. This is maybe 15 minutes of work —
I flagged it as unbuilt so you know it's not silently missing.

**For visualisation**, `outputs/geojson/scenario.geojson` (Tx + deployment
polygon) is already formatted to drop straight into a QGIS project — that
part needs no code from either of you.

### 3.3 Final integration (all three modules together)

Nobody has to rewrite Module C for the merge. The three modules hand off
through files, per the original architecture doc:

- **GIS (Person 1)** → GeoJSON/CSV: Tx, Rx, terrain/coverage polygons, LOS
- **Propagation (Person 2)** → CSV/JSON: Tx-Rx pair, frequency, path loss,
  quality
- **Optimization (Module C, this)** → CSV/JSON: candidate Rx coordinates,
  selected Rx coordinates, geometry metrics — **already produced**, sitting
  in `outputs/csv/` and `outputs/geojson/` right now

The full contract, with every column name and type spelled out, is in
`config/integration_schemas.yaml` — that file is the thing to hand your
teammates rather than re-deriving it from this doc.

---

## PART 4 — QUICK TROUBLESHOOTING

| Symptom | Likely cause | Fix |
|---|---|---|
| `ModuleNotFoundError: No module named 'src'` | Running a script from the wrong directory | Run from `module_C_optimization/`, or use `run_pipeline.py` which fixes the path itself |
| `ValueError: all candidates were rejected` | Constraints too strict for the polygon/grid size | Loosen `min_rx_separation_m` or reduce `grid_spacing_m` in `config.yaml` |
| `ValueError: no candidates generated` | Grid spacing larger than the polygon | Reduce `candidates.grid_spacing_m` |
| Exhaustive reference skipped | C(K,N) exceeded `exhaustive_max_combinations` | Expected for large candidate sets — raise the cap if you have time to wait, or accept there's no exact reference |
| `pip install shapely` fails | No network / platform issue | Not required — the pipeline runs on the NumPy fallback regardless |
| Plots look different between runs | You changed a seed in `config.yaml` | All randomness is seeded; identical config + seeds = identical output (verified by `test_pipeline_is_deterministic`) |

---

## PART 5 — FILE MAP (what to open for what)

```
README.md                        → mathematics, current results, honest status table
this file                        → running it, integrating it, what's left
config/config.yaml                → every tunable number
config/integration_schemas.yaml  → exact handoff contract for Persons 1 & 2
run_pipeline.py                  → CLI entry point
src/gdop.py                      → the core DF mathematics, read this first if reviewing the theory
src/pipeline.py                  → the orchestration — read this to see the whole flow at a glance
src/mock_propagation.py          → SYNTHETIC layer + the propagation_from_external() integration point
tests/                            → 68 tests; test_gdop.py is the one worth reading for the maths
notebooks/optimization_demo.ipynb → step-by-step walkthrough, same calls as the CLI
```
